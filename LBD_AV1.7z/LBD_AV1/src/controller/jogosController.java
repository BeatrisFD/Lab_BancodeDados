package controller;

import java.util.Date;
import java.util.List;

import dao.IJogosDao;
import dao.JogosDao;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Grupo;
import model.Jogo;

public class jogosController {
	private ObservableList<Jogo> lista = 
			FXCollections.observableArrayList();
	
	public void buscarTodosJogos() {
		IJogosDao jDao = new JogosDao();
		List<Jogo> listaTemp = jDao.buscarTodosJogos();
		for (Jogo grupo : listaTemp) {
			lista.add(grupo);
		}
	}
	
	public void buscarJogosNaData(Date dia) {
		IJogosDao jDao = new JogosDao();
		List<Jogo> listaTemp = jDao.buscarJogosPorData(dia);
		for (Jogo grupo : listaTemp) {
			lista.add(grupo);
		}
	}
	
	public void gerarRodadas() {
		//TODO 
	}
}
