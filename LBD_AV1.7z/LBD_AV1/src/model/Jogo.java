package model;

import java.util.Date;

public class Jogo {
	private int codTimeA;
	private int codTimeB;
	private int golsTimeA;
	private int golsTimeB;
	private Date data;
	
	public Jogo(int codTimeA, int codTimeB, int golsTimeA, int golsTimeB, Date data) {
		super();
		this.codTimeA = codTimeA;
		this.codTimeB = codTimeB;
		this.golsTimeA = golsTimeA;
		this.golsTimeB = golsTimeB;
		this.data = data;
	}
	
	public int getCodTimeA() {
		return codTimeA;
	}
	public void setCodTimeA(int codTimeA) {
		this.codTimeA = codTimeA;
	}
	public int getCodTimeB() {
		return codTimeB;
	}
	public void setCodTimeB(int codTimeB) {
		this.codTimeB = codTimeB;
	}
	public int getGolsTimeA() {
		return golsTimeA;
	}
	public void setGolsTimeA(int golsTimeA) {
		this.golsTimeA = golsTimeA;
	}
	public int getGolsTimeB() {
		return golsTimeB;
	}
	public void setGolsTimeB(int golsTimeB) {
		this.golsTimeB = golsTimeB;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	
	
}
