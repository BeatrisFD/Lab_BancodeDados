package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import model.Jogo;

public class JogosDao implements IJogosDao {

	@Override
	public List<Jogo> buscarTodosJogos() {
		List<Jogo> lista = new LinkedList<Jogo>();
		String sql = "SELECT * FROM jogos";
		try {
			PreparedStatement ps= GenericDao.getInstancia().getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Jogo j = new Jogo(rs.getInt("codigo_timeA"), rs.getInt("codigo_timeB"), rs.getInt("gols_timeA"), rs.getInt("gols_timeB"), rs.getDate("data_jogo"));
				lista.add(j);
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}

	@Override
	public List<Jogo> buscarJogosPorData(Date dia) {
		List<Jogo> lista = new LinkedList<Jogo>();
		String sql = "SELECT * FROM jogos WHERE data_jogo LIKE ?";
		try {
			PreparedStatement ps= GenericDao.getInstancia().getConnection().prepareStatement(sql);
			ps.setString(1, dia.toString());
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Jogo j = new Jogo(rs.getInt("codigo_timeA"), rs.getInt("codigo_timeB"), rs.getInt("gols_timeA"), rs.getInt("gols_timeB"), rs.getDate("data_jogo"));
				lista.add(j);
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;

	}

	@Override
	public void adicionarJogo(Jogo jogo) {
		String sql = "INSERT INTO jogos (codigo_timeA,codigo_timeB,gols_timeA,gols_timeB,data_jogo) "
				+ "VALUES(?,?,?,?,?) ";
		try {
			PreparedStatement ps  = GenericDao.getInstancia().getConnection().prepareStatement(sql);
			ps.setInt(1, jogo.getCodTimeA());
			ps.setInt(1, jogo.getCodTimeB());
			ps.setInt(1, jogo.getGolsTimeA());
			ps.setInt(1, jogo.getGolsTimeB());
			ps.setString(5, jogo.getData().toString());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
