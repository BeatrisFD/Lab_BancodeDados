package dao;

import java.util.Date;
import java.util.List;

import model.Jogo;

public interface IJogosDao {
	public List<Jogo> buscarTodosJogos();
	public List<Jogo> buscarJogosPorData(Date dia);
	public void adicionarJogo(Jogo jogo);
}
