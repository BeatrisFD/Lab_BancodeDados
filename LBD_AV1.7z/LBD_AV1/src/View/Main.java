package View;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import dao.GenericDao;
import dao.GruposDao;
import dao.IGenericDao;
import dao.TimesDao;
import model.Grupo;
import model.Time;

public class Main {

	public static void main(String[] args) {
		/*
		 * GenericDao.getInstancia().getConnection(); TimesDao td = new TimesDao(); for
		 * (Time t : td.getAllTimes() ) { System.out.println(t.getNomeTime()); }
		 */
		
		Date d = new Date();
		System.out.println(d.toString());
	}
}
